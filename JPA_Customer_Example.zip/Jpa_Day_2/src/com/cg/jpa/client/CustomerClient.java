package com.cg.jpa.client;

import java.util.Date;
import java.util.Scanner;

import com.cg.jpa.entities.Customer;
import com.cg.jpa.service.CustomerServiceImpl;
import com.cg.jpa.service.ICustomerService;



public class CustomerClient {
	
	private static Scanner sc = new Scanner(System.in);
	static ICustomerService  service = new CustomerServiceImpl();
	static Customer c = new Customer();

	public static void main(String[] args) {
		
	
		int ch = 0;
	
		do
		{
			System.out.println("Enter Your Choice \n"
					+ "1.Add Details \n"
					+ "2.Get Details by id \n"
					+ "3.Get Details By Mobile number \n"
					+ "4.Display All details\n"
					+ "5.Get Count \n"
					+ "6.Update Customer \n"
					+ "7.Delete Customer \n"
					+ "8.Exit");
			
			ch = sc.nextInt();
		
			switch(ch)
			{
			
			case 1:
				addCustomer();
				break;
		
			case 2:
				findById();
				break;
		
			case 3:
				findWithMobile();
				break;
		
			case 4:
				getAllCustomers();
				break;
				
			case 5:
				getCount();
				break;
				
			case 6:
				updateCustomer();
				break;
				
			case 7:
				deleteCustomer();
				break;
			case 8:
				System.out.println("Thank You !!!");
				System.exit(0);
				break;
		
			}
		
		
		}
		while(ch!=8);
		
		
	}
	
	

	private static void addCustomer()
	{
		
		System.out.println("Enter Customer Name :");
		c.setName(sc.next());
		System.out.println("Enter Customer id :");
		c.setId(sc.nextInt());
		System.out.println("Enter Customer Mobile :");
		c.setMobile(sc.nextLong());
		System.out.println("Enter Customer Email :");
		c.setEmail(sc.next());
		c.setDob(new Date());
		service.addCustomer(c);
		System.out.println("Customer details inserted !!!");
	}
	
	private static void findById()
	{
		System.out.println("Customer with ID :\n");
		service.findById(1001);
	}
	
	private static void findWithMobile()
	{
		System.out.println("Enter Customer Mobile :");
		System.out.println("Details are :\n"+service.findWithMobile(sc.nextLong()));

	}
	private static void getAllCustomers()
	{
		System.out.println("***********Customer Details **********");
		for (Customer customer:service.getAllCustomers())
		{
			System.out.println(customer);
		}
		
		/*for (Customer customer:service.getAllDeatis())
		{
			System.out.println(customer);
		}*/
	}
	
	private static void getCount()
	{
		System.out.println("*************Total Number of Enteries********");
		System.out.println(service.getCount());
	}
	private static void updateCustomer()
	{
		System.out.println("Enter the Customer ID to Update :\n");
		c =  service.findById(sc.nextInt());
		
		if(c==null)
		{
			System.out.println("Id does not exits!!!");
		}
		else
		System.out.println("Enter Customer Name :");
		c.setName(sc.next());
		System.out.println("Enter Customer Mobile :");
		c.setMobile(sc.nextLong());
		System.out.println("Enter Customer Email :");
		c.setEmail(sc.next());
		
		service.updateCustomer(c);
		System.out.println("Updation Done");
	}

	private static void deleteCustomer() {
	
		System.out.println("Enter the Customer ID to delete Records :\n");
		c =  service.findById(sc.nextInt());
		if(c==null)
		{
			System.out.println("Id does not exits!!!");
		}
		else
		{
			service.deleteCustomer(c);
			System.out.println("Details deleted successfully !!!");
		}
		
		
	}

	
}
	
	
	


