package com.cg.jpa.service;

import java.util.List;

import com.cg.jpa.entities.Customer;


public interface ICustomerService {

	public void addCustomer(Customer c);

	public Customer findById(int id);
	
	public Customer findWithMobile(long mob);

	public List<Customer> getAllDeatis();

	public Long getCount();

	public abstract void updateCustomer(Customer c);

	public List<Customer> getAllCustomers();
	
	public abstract void deleteCustomer(Customer c);


	
}
