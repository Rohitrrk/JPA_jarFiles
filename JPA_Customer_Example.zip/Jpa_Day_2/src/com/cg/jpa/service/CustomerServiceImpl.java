package com.cg.jpa.service;

import java.util.List;

import com.cg.jpa.dao.CustomerDaoImpl;
import com.cg.jpa.dao.ICustomerDao;
import com.cg.jpa.entities.Customer;

public class CustomerServiceImpl implements ICustomerService{

	ICustomerDao dao = new CustomerDaoImpl();
	
	@Override
	public void addCustomer(Customer c) {
		dao.beginTransaction();
		dao.addCustomer(c);
		dao.commitTransaction();
	}

	@Override
	public Customer findById(int id) {
		return dao.findById(id);
		
	}

	@Override
	public Customer findWithMobile(long i) {
	
		return dao.findWithMobile(i);
	}

	@Override
	public List<Customer> getAllDeatis() {
		
		return dao.getAllDeatis();
	}

	@Override
	public Long getCount() {
		
		return dao.getCount();
	}

	@Override
	public void updateCustomer(Customer c) {
		dao.beginTransaction();
		dao.addCustomer(c);
		dao.commitTransaction();
		
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return dao.getAllCustomers();
	}

	@Override
	public void deleteCustomer(Customer c) {
			dao.beginTransaction();
			dao.deleteCustomer(c);
			dao.commitTransaction();
		
	}

	
	
	
	

}
