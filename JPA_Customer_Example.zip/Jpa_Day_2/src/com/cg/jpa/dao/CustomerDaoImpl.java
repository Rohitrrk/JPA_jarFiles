package com.cg.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpa.entities.Customer;
import com.cg.jpa.util.JPAUtil;



public class CustomerDaoImpl implements ICustomerDao {

	private EntityManager entityManager;

	public CustomerDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public void addCustomer(Customer c) {
		entityManager.persist(c);
		
	}

	@Override
	public Customer findById(int id) {
		
		Customer customer = entityManager.find(Customer.class, id);
		return customer;
	}

	@Override
	public Customer findWithMobile(long mob) {
		
		String sql = "SELECT c FROM Customer c where mobile = :mob";
		TypedQuery<Customer> query = entityManager.createQuery(sql, Customer.class);
		query.setParameter("mob",mob);
		Customer cust = query.getSingleResult();
		return cust;
		
	}

	@Override
	public List<Customer> getAllDeatis() 
	{
		String sql = "SELECT c FROM Customer c";
		TypedQuery<Customer> query = entityManager.createQuery(sql, Customer.class);
		List<Customer> cust = query.getResultList();
		return cust;
		
	}

	@Override
	public Long getCount() {
		
		String sql = "SELECT COUNT(c) FROM Customer c";
		TypedQuery<Long> query = entityManager.createQuery(sql, Long.class);
		Long count = query.getSingleResult();
		return count;
	}



	@Override
	public void updateCustomer(Customer c) {
		entityManager.merge(c);
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		Query query = entityManager.createNamedQuery("getAllCustomer");
		@SuppressWarnings("unchecked")
		List<Customer> cust = query.getResultList();
		return cust;
	}	
	
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void deleteCustomer(Customer c) {
		entityManager.remove(c);
		
	}
	
	
}
